<i>This project has been created as part of the 42 curriculum by oamkhou outaouss</i>
<h1>Description</h1>
<ul>
  <strong>A-Maze-ing</strong> is a python project that generates and displays mazes using maze generation algorithms <br>
  The goal of the project is to explore algorithmic maze construction while respecting structural constraints <br>
  The project implements different maze generation strategies such as Depth-First Search and Breadth-First Search to solve the maze and provide the shorteast path.<br>
  In addition we add different bounuses part like Play Mode with more options.<br>
  <strong>Project Goals</strong>
  <ul>
  <li>Understand and implement graph traversal algorithms</li>
  <li>Compare different procedural generation techniques</li>
  <li>Write clean, typed Python code (mypy compliant)</li>
  <li>Provide a fully automated Makefile workflow</li>
  <li>Package implement</li>
  </ul>
</ul>


<h1>Instructions</h1>
<ul>
  <strong>Installation</strong> <br>
  <small>Clone the repository and install dependencies:</small> <br>
  <code>make install</code>
  <br>
  <small>This installs required packages using <code>pip</code> and the <code>requirements.txt</code> file.</small> <br>
  <br>
  <strong>Run the Project</strong> <br>
  <code>make run</code> <br>
  <small>This executes the main script using Python.</small> <br>
  <br>
  <strong>Debug Mode</strong> <br>
  <code>make debug</code> <br>
  <small>Runs the program using Python’s built-in debugger (<code>pdb</code>).</small>
  <br><br>
  <strong>Linting</strong> <br>
  <small>Check code quality and static typing:</small> <br>
  <code>make lint</code> <br>
  <small>
    This runs:
    <ul>
    <li><code>flake8</code></li>
    <li><code>mypy</code> with strict typing flags</li>
    </ul>
  </small>
  <br>
  <strong>Clean Temporary Files</strong> <br>
  <code>make clean</code> <br>
  <small>
  Removes:
  <ul>
    <li><code>__pycache__</code></li>
    <li><code>.mypy_cache</code></li>
  </ul>
  </small>
</ul>


<h1>Resources</h1>
<ul>
  <strong>Maze Generation References</strong>
  <ul>
      <li>Youtube</li>
    <ul>
    <a href= "https://youtu.be/ioUl1M77hww?si=rY_LKxkN0dleR-Tm">
      Maze Generation Algorithms</a>
      <br>
      <a href="https://youtu.be/umszOeerdsU?si=58vsdBDCsxa7yX4E">
        Theseus and the Minotaur | Exploring State Space
      </a>
    </ul>
    <li>Wikipidia</li>
    <ul>
      <a href="https://en.wikipedia.org/wiki/Maze_generation_algorithm">
        Maze generation algorithm
      </a>
    </ul>
    <li>Ascii rendering</li>
    <ul>
      <a href="https://www.compart.com/en/unicode/block">
      compart
      </a>
    </ul>
  </ul>
  <sgrong>AI Usage</strong>
  AI tools (ChatGPT) were used during development for:
  <ul>
    <li>Clarification of algorithmic concepts (DFS, Hunt-and-Kill, Prim)</li>
    <li>Understanding Python typing and mypy errors</li>
    <li>Debugging circular import issues</li>
    <li>Improving Makefile configuration</li>
  </ul>
  AI assistance was used strictly for explanation, debugging guidance, and documentation support — not for direct copy-paste of complete solutions.
  <strong>Technologies Used</strong>
  <ul>
    <li>Python 3</li>
    <li>ANSI terminal rendering</li>
    <li>flake8</li>
    <li>mypy</li>
    <li>Makefile automation</li>
  </ul>
  <h1>Config file structure and format</h1>
  <ul>
    <small>
      the config file providing as a key=value format <br>
      <ul>
        <code>
          # reqire entires <br>
          WIDTH=width size  <br>
          HEIGHT=height size <br>
          ENTRY=x, y <br>
          EXIT=x, y <br>
          OUTPUT_FILE=output_file <br>
          PERFECT= boolean is activated, the maze must contain exactly one path between the entry and the exit <br>
          # optional entries <br>
          ANIMATE= boolean <br>
          SEED= integer to get a maze seed <br>
          HALLUCINATION=boolean themes effect when play mode is actived <br>
        </code>
      </ul>
    </small>
  </ul>
</ul>

<h1>chosen maze generation algorithm</h1>
<ul>
  <h3>Depth-First Search (DFS) – Recursive Backtracker</h3>
  <strong>Description</strong>
  <ul>
    The first algorithm implemented is the Depth-First Search (DFS) maze generator, also known as the Recursive Backtracker.
    <br>
    it works by:
    <ul>
      <li>Starting from an initial cell.</li>
      <li>Randomly selecting an unvisited neighbor.</li>
      <li>Carving a passage and moving forward.</li>
      <li>Backtracking when no unvisited neighbors remain.</li>
    </ul>
    This process continues until all cells have been visited.
  </ul>

  <strong>Why We Chose DFS</strong>
  <ul>
    DFS was chosen because:
    <ul>
      <li>It is simple to implement and understand.</li>
      <li>It produces clean, long corridors.</li>
      <li>It guarantees a perfect maze (only one path between any two cells).</li>
      <li>It is widely documented and academically recognized.</li>
    </ul>
    <br>
    <h3>Breadth-First Search (BFS)</h3>
  <strong>Description</strong>
  <ul>
    The second approach is inspired by Breadth-First Search (BFS) principles. <br>
    Instead of exploring deeply along one path, BFS-based generation expands outward layer by layer, using a frontier structure (queue or frontier list).
    <br>
    This produces mazes that:
    <ul>
      <li>Have more branching</li>
      <li>Contain shorter corridors</li>
      <li>Look more “balanced” and less linear</li>
    </ul>
  </ul>

  <strong>Why We Chose BFS</strong>
  <ul>
    BFS was selected because:
    <ul>
      <li>BFS is primarily used to find the shortest path in an unweighted graph.</li>
      <li>Find shortest path</li>
    </ul>
  </ul>
</ul>

